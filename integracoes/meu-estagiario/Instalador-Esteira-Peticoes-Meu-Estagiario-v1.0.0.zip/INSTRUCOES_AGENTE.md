# Instruções para o agente instalador

1. Confirme que o destino é o clone privado do escritório e que o núcleo do Kit já está instalado.
2. Obtenha a chave por caixa segura ou secret store. Nunca peça que seja colada na conversa.
3. Rode os testes locais e depois `instalar.py --kit-root ... --test-write`.
4. O teste deve usar somente tarefa sintética e ser arquivado; nunca use caso ou cliente real.
5. Confira o arquivo de resultado. HTTP 200 sem leitura de volta não é prova.
6. Não escreva em financeiro, não altere skills do Meu Estagiário e não use `/chat`.
7. O Sync permanece somente leitura. Aprovação jurídica e protocolo manual são gates distintos.
8. Não prometa sincronização contínua: `ponte.py` espelha uma tarefa quando invocado; um worker
   permanente precisa ser instalado, agendado e comprovado separadamente.

Informe ao usuário: conta validada, catálogos lidos, teste sintético, caminho da configuração local
e se houve vínculo exato de caso e responsável. Nunca mostre a chave.
